# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['src']

package_data = \
{'': ['*']}

install_requires = \
['nox-poetry>=1.2.0,<2.0.0', 'nox>=2025.2.9,<2026.0.0']

setup_kwargs = {
    'name': 'src',
    'version': '0.1.0',
    'description': '',
    'long_description': "Header 1\n========\n--------\nSubtitle\n--------\nhttps://python-poetry.org/\nhttps://medium.com/@cristobalcl/set-up-tests-linters-and-type-checking-in-python-projects-in-2020-9cc1b1e2750d\n\npoetry lock\ndocker build . -t exa1\n\n\nExample text.\n\n.. contents:: Table of Contents\n\nHeader 2\n--------\n\n1. Blah blah ``code`` blah\n\n2. More ``code``, hooray\n\n3. Somé UTF-8°\n\nThe UTF-8 quote character in this table used to cause python to go boom. Now docutils just silently ignores it.\n\n.. csv-table:: Things that are Awesome (on a scale of 1-11)\n\t:quote: ”\n\n\tThing,Awesomeness\n\tIcecream, 7\n\tHoney Badgers, 10.5\n\tNickelback, -2\n\tIron Man, 10\n\tIron Man 2, 3\n\tTabular Data, 5\n\tMade up ratings, 11\n\n.. code::\n\n\tA block of code\n\n.. code:: python\n\n\tpython.code('hooray')\n\n.. code:: javascript\n\n\texport function ƒ(ɑ, β) {}\n\n.. doctest:: ignored\n\n\t>>> some_function()\n\t'result'\n\n>>> some_function()\n'result'\n\n==============  ==========================================================\nTravis          http://travis-ci.org/tony/pullv\nDocs            http://pullv.rtfd.org\nAPI             http://pullv.readthedocs.org/en/latest/api.html\nIssues          https://github.com/tony/pullv/issues\nSource          https://github.com/tony/pullv\n==============  ==========================================================\n\n\n.. image:: https://scan.coverity.com/projects/621/badge.svg\n\t:target: https://scan.coverity.com/projects/621\n\t:alt: Coverity Scan Build Status\n\n.. image:: https://scan.coverity.com/projects/621/badge.svg\n\t:alt: Coverity Scan Build Status\n\nField list\n----------\n\n:123456789 123456789 123456789 123456789 123456789 1: Uh-oh! This name is too long!\n:123456789 123456789 123456789 123456789 1234567890: this is a long name,\n\tbut no problem!\n:123456789 12345: this is not so long, but long enough for the default!\n:123456789 1234: this should work even with the default :)\n\nsomeone@somewhere.org\n\nPress :kbd:`Ctrl+C` to quit\n\n\n.. raw:: html\n\n    <p><strong>RAW HTML!</strong></p><style> p {color:blue;} </style>",
    'author': 'beortner',
    'author_email': 'bernhardortner@gmx.net',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
